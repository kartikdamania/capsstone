export default  {
  products: [
    {
      _id: '1',
      name: 'White Shirt',
      category: 'Shirts',
      image: '/images/d1.jpg',
      price: 30,
      brand: ' Raymond',
      rating: 4.2,
      numReviews: 11
    },
    {
      _id: '2',
      name: 'Nike Shoe',
      category: 'Shoes',
      image: '/images/p2.jpg',
      price: 50,
      brand: ' Nike',
      rating: 4.8,
      numReviews: 5
    },
    {
      _id: '3',
      name: 'iPhone 11',
      category: 'Apple',
      image: '/images/p3.jpg',
      price: 900,
      brand: ' Apple',
      rating: 4.3,
      numReviews: 20
    }, {
      _id: '4',
      name: 'Tablet',
      category: 'Smart Device',
      image: '/images/p4.jpg',
      price: 700,
      brand: ' Samsung',
      rating: 4.5,
      numReviews: 8
    },
    {
      _id: '5',
      name: 'Macbook',
      category: 'Laptop',
      image: '/images/p5.jpg',
      price: 950,
      brand: ' Apple',
      rating: 4.1,
      numReviews: 9
    },
    {
      _id: '6',
      name: 'Smart Watch',
      category: 'Watch',
      image: '/images/p6.jpg',
      price: 200,
      brand: ' Samsung',
      rating: 4.9,
      numReviews: 9
    },
  ]
}